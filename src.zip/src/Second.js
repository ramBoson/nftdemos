import React, { useState, useEffect } from 'react';
import history from "./utils/history";
import ReactDOM from "react-dom";
import getaaa from "./cabi";



function Example() {
  const val=  getaaa.methods.totalSupply.call();

  const [count, setCount] = useState(val);

  // Similar to componentDidMount and componentDidUpdate:
  //useEffect(() => {
    // Update the document title using the browser API
    //document.title = `You clicked ${count} times`;
  //});

  return (
    <div>
      <p>You clicked ${count} times</p>
      <button onClick={() => setCount(count + 1)}>
        Click me
      </button>
    </div>
    
  );
}

export default Example;
